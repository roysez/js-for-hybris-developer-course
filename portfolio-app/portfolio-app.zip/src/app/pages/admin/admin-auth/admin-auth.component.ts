import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-auth',
  templateUrl: './admin-auth.component.html',
  styleUrls: ['./admin-auth.component.scss']
})
export class AdminAuthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
